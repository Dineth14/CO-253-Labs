#include<stdio.h>

    int main(){

    int num1;
    int num2;
    int sum;

    printf("number 1: \n");
    scanf("%d", &num1);

    printf("number 2: \n");
    scanf("%d", &num2);

    sum = num1 + num2 ;

    printf("sum = %d\n", sum);
    return 0;
}

